## zeby odpalic 
```
npm run dev
```
