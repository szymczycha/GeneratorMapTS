export interface Square {
    canvas: HTMLCanvasElement;
    context: CanvasRenderingContext2D;
}